import numpy as np
import argparse
import numpy.random as nr
import sys
import pdb
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import auc



class LogReg(object):
    # W1: d x d, W2: d x 1, b: scalar
    def __init__(self, d, lamb):
        self.W1 = nr.randn(d, d)
        self.W2 = nr.randn(d)
        self.b = nr.randn()
        self.lamb = lamb  # To be multiplied on the regularization term.

    def foo(self, x):
        return np.dot(x, np.dot(self.W1, x)) + np.dot(x, self.W2) + self.b

    def logistic(self, x):
        return 1 / (1 + np.exp(-self.foo(x)))

    # TODO: Implement the log-likelihood function of the data
    def log_likelihood(self, data, labels):
        log_likelihood = 0
        for i in range(len(data)):
            log_likelihood += labels[i]*np.log(self.logistic(data[i]))+ (1-labels[i])* np.log(1 - self.logistic(data[i]))
        return log_likelihood 

    # TODO: Implement the derivatives of the log-likelihood w.r.t. each parameter, evaluated at x (x is d x 1)
    def dLLdW1(self, x, y):
        p = self.logistic(x)
        return np.outer(x, x) * (y -p)
  
    def dLLdW2(self, x, y):
        p = self.logistic(x) 
        return x * (y -p)
    
    def dLLdb(self, x, y):
        p = self.logistic(x)
        return 1 * (y -p)

    # TODO: Return the L2 regularization term.
    def l2_reg(self):
        reg = 0.5 * self.lamb * (np.linalg.norm(self.W1)**2 + np.linalg.norm(self.W2)**2) #+ (self.b)**2)
        return reg

    # TODO: Implement the classification rule on x (i.e., what is the label of x?)
    def predict(self, x):
        if self.logistic(x) >= 0.5:
            return 1
        else:
            return 0

    # TODO: Implement a single gradient ascent step, and return the objective (*not* the log-likelihood!!)
    # Question: What is the objective? -  objective is to maximize the likelihood function
    def step(self, dat, lbl, lr):
        dW1 = np.zeros_like(self.W1)
        dW2 = np.zeros_like(self.W2)
        db = 0
        N = len(dat)
        for i in range(N):
            xi = dat[i]
            yi = lbl[i]
            dW1 += self.dLLdW1(xi,yi) 
            dW2 += self.dLLdW2(xi,yi)   
            db += self.dLLdb(xi,yi)  

        # Update parameters
        self.W1 += lr * (dW1 + 2*self.lamb * self.W1)
        self.W2 += lr * (dW2+ 2*self.lamb * self.W2)
        self.b += lr * (db)

        # Return the objective
        objective = -(1/N)*self.log_likelihood(dat, lbl)+ self.l2_reg()
        return objective
    
    def plot_precision_recall_curve(self, test_data, test_gt):
        preds = []
        for i in range(len(test_data)):
            xi = test_data[i]
            prob = self.logistic(xi)
            preds.append(prob)
        precision, recall, _ = precision_recall_curve(test_gt, preds)# precision-recall curve on actaul and predicted labels
        pr_auc = auc(recall, precision)
        plt.plot(recall, precision, label='PR curve (area = %0.2f)' % pr_auc)
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.title('Precision-Recall Curve')
        plt.legend(loc="lower right")
        plt.show() 

    # TODO: Implement the F1 measure computation. 
    def f1(self, test_data, test_gt): # removed step as first parameter and replaced with self
        tp = fp = fn = 0
        for i in range(len(test_data)):
            xi = test_data[i]
            yi = test_gt[i]
            if self.predict(xi) == 1 and yi == 1:
                tp += 1
            elif self.predict(xi) == 1 and yi == 0:
                fp += 1
            elif self.predict(xi) == 0 and yi == 1:
                fn += 1
        precision = tp / (tp + fp)
        recall = tp / (tp + fn)
        f1 = 2 * (precision * recall) / (precision + recall)
        return f1         


# Returns a numpy array of size n x d, where n is the number of samples and d is the dimensions
def read_data(filename):
    data = []
    labels = []
    with open(filename, 'r') as f:
        tmp = f.readlines()
    for line in tmp:
        toks = line.split(',')
        lbl = int(toks[0])
        dat = np.array([float(x.strip()) for x in toks[1:]])
        if len(data) == 0: data = dat
        else: data = np.vstack((data, dat))
        labels.append(lbl)
    return data, labels

def main(args): 
    num_epoch = args.epochs
    learning_rate = args.lr #1e-3 = 0.001
    lamb = args.lamb # changed lambda - keyword to lamb ->> regularization term

    tr_data, tr_gt = read_data('train.csv')
    va_data, va_gt = read_data('val.csv')
    te_data, te_gt = read_data('test.csv')
    model = LogReg(tr_data.shape[-1], lamb)

    Ltrain = []
    Lval = []
    N = len(va_data)

    # An EPOCH is a single pass over the entire dataset.
    # Normally, we'd run this epoch loop until the learning has converged, but we'll
    # just run a fixed number of loops for this assignment.
    for ep in range(num_epoch):
        loss = model.step(tr_data, tr_gt, learning_rate) 
        Ltrain.append(loss)
        # Maybe add your own learning rate scheduler here?
        #validation loss
        Lval.append(-(1/N)*model.log_likelihood(va_data, va_gt)+ model.l2_reg()) 
        print('[Epoch {}] Regularized loss = {}'.format(ep, loss))
        print(f"Epoch {ep+1}/{args.epochs} | Train Loss: {loss:.2f} | Val Loss: {Lval[-1]:.2f} | train Accuracy: {model.f1(tr_data, tr_gt)} | test Accuracy: {model.f1(te_data, te_gt)}")

    
    # Plot the training and validation loss
    plt.plot(Ltrain, label="Train Loss")
    plt.plot(Lval, label="Val Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.legend()
    plt.show()
    print('F1 score on test data = {}'.format(model.f1(te_data, te_gt)))

    model.plot_precision_recall_curve(te_data, te_gt)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", type=str, default="train.csv", help="Training data file")
    parser.add_argument("--val", type=str, default="val.csv", help="Validation data file")
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--lamb", type=float, default=1e-6)
    parser.add_argument("--epochs", type=int, default=100)
    args = parser.parse_args()
    main(args)
