import numpy as np
import numpy.linalg as nl
import numpy.random as nr
import matplotlib.pyplot as plt


class KMeans(object):
    def __init__(self, data):
        self.data = data
        self.centroids = None
        self.labels = None
        self.assignments = np.zeros(data.shape[0])
        
    # TODO: Perform k-means clustering.
    def run(self, K):
        # Initialize centroids
        self.centroids = self.data[nr.choice(self.data.shape[0], K, replace=False)]
        while True:
            # Assign points to clusters
            eqdistances = np.sqrt(np.sum((self.data[:, np.newaxis, :] - self.centroids) ** 2, axis=2))
            self.labels = np.argmin(eqdistances, axis=1)
            #print(self.labels)
            # Update centroids with mean of clusters it belogs to
            new_centroids = np.array([np.mean(self.data[self.labels == i], axis=0) for i in range(K)])
            if np.allclose(new_centroids, self.centroids): #atol=1e-4 or 1e-3
                break
            self.centroids = new_centroids
        # Compute assignments for final centroids
        distances = np.sqrt(np.sum((self.data[:, np.newaxis, :] - self.centroids) ** 2, axis=2))
        self.assignments = np.argmin(distances, axis=1)  

    # TODO: Compute the Silhouette score
    def sil(self):
        s = 0
        for i in range(self.data.shape[0]):
            # Computing a(i) for each point
            cluster = self.labels[i]
            a = np.mean(nl.norm(self.data[self.labels == cluster] - self.data[i], axis=1))

            # Computing b(i) for each point
            b = np.inf
            for j in range(self.centroids.shape[0]):
                if j == cluster:
                    continue
                d = np.mean(nl.norm(self.data[self.labels == j] - self.data[i], axis=1))
                b = min(b, d)

            # Sum of Silhouette score for each point 
            s += (b - a) / max(a, b)
            
        #Silhouette score for the entire clustering
        sil_score = s / self.data.shape[0]
        return sil_score

    # TODO: Implement and perform PCA to 'd' dimensions and return the compressed dataset.
    # The numpy.linalg module provides many useful functions related to matrix operations.
    def visualize(self, d=2):
        # calculate mean and subtract mean from data
        data_mean = np.mean(self.data, axis=0)
        Mean_cent_data = self.data - data_mean

        # Compute the covariance matrix
        cov_matrix = np.cov(Mean_cent_data , rowvar = False)
        #print('Cov',cov)

        # Compute the eigenvalues and eigenvectors
        eigenvalues, eigenvectors = nl.eigh(cov_matrix)
        Sort_idx = np.argsort(eigenvalues)[::-1]
        Sort_eigenvectors = eigenvectors[:, Sort_idx]

        # Project the data with the highest eigenvalues onto the d principle components
        components = Sort_eigenvectors[:, 0:d]
        reduced_proj = np.dot(components.transpose() , Mean_cent_data.transpose() ).transpose()

        return reduced_proj
        
# Returns a numpy array of size n x d, where n is the number of samples and d is the dimensions
# You're free to change this function.
def read_data(filename):
    data = []
    with open(filename, 'r') as f:
        tmp = f.readlines()
    for line in tmp:
        toks = line.split(',')
        dat = np.array([float(x.strip()) for x in toks[0:]])
        if len(data) == 0: data = dat
        else: data = np.vstack((data, dat))
    return data

def main(): 
    tr_data = read_data('train.csv')

    ########################## K-means clustering ######################################
    ### Below is just a sample code to demonstrate how the function should be run ######
    ### You're free to modify it as you like ###########################################
    ####################################################################################

    k = 3 # 2-means clustering
    kmc = KMeans(tr_data)
    kmc.run(k)
    print('K: {}, Silhouette: {}'.format(k, kmc.sil()))

    compressed = kmc.visualize()
    # Use whatever plotting software you like to plot the compressed clusters. (matplotlib, maybe?)
    fig, ax = plt.subplots()
    ax.scatter(compressed[:, 0], compressed[:, 1], c=kmc.assignments)
    ax.set_title('Compressed Clusters')
    ax.set_xlabel('Principal Component 1')
    ax.set_ylabel('Principal Component 2')
    plt.show()


if __name__ == '__main__':
    main()  # Use command-line arguments if you need to
