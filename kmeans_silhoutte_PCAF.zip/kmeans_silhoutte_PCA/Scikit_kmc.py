import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

# read data from CSV file
data = pd.read_csv("train.csv")

# drop any rows with missing values
data = data.dropna()

# convert data to numpy array
X = np.array(data)

# choose number of clusters
k = 6

# train k-means clustering model
kmeans = KMeans(n_clusters=k)
kmeans.fit(X)

# predict cluster labels
labels = kmeans.predict(X)

# calculate silhouette score
silhouette_avg = silhouette_score(X, labels)

# print results
print("Cluster labels: ", labels)
print("Silhouette score: ", silhouette_avg)

# plot the clusters
plt.scatter(X[:, 0], X[:, 1], c=kmeans.labels_)
plt.title('K-means clustering')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()

