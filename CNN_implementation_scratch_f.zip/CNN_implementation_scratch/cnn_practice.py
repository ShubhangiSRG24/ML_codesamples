import numpy as np
import numpy.random as nr
import cv2

class MyCNN:
    # You may freely modify the constructor in any way you want.
    def __init__(self):
        # Initialize the convolution filters
        ...

    # TODO: Implement conv() and pool(). Should be able to handle various values of stride and padding.
    # The size of 'img' is bs x nc x w x h (bs == batch size, nc == number of channels)
    # The size of 'filters' is ni x w x h x no, where 'ni' is the number of input channels and 'no' is the number of output channels.
    def conv(self, img, filters, stride=1, padding=0):
        # I have not considered bs as we have a single input image and thus bs=1
        nc, w, h = img.shape
        ni, w_f, h_f, no = filters.shape

        # pad the w and h of input image with 0
        ipad_mat = np.pad(img, ((0,0), (padding,padding), (padding,padding)), mode='constant', constant_values=0)
        
        # use [(W−K+2P)/S]+1 fi=ormula to calculate the size of the output of convolution layer
        w_o, h_o = int((w - w_f + 2 * padding) // stride) + 1, int((h - h_f + 2 * padding) // stride) + 1

        #initialize o/p matrix of above size with zeros - empty feature map
        o_mat = np.zeros((no, w_o, h_o))

        # Perform convolution operation
        for o in range(no): #iterate over totla number of output channels= 10
            for i in range(ni): # iterate through each of the 3 input channels of a filter
                for x in range(w_o):
                    for y in range(h_o):
                        Fil_i_o = filters[i, :, :, o] # (i+1)th filter/filter_index , all elements along width and height and (o+1)th specific output channel from a set of filters 
                        o_mat[o, x, y] = o_mat[o, x, y] + np.sum(ipad_mat[i, x * stride:x * stride + w_f, y * stride:y * stride + h_f] * Fil_i_o) # update convolution calculation values in the empty feature map

        return o_mat

    # TODO: Implement pooling. The 'ptype' variable can be either 'max' or 'avg' (max pooling and average pooling).
    def pool(self, img, size=2, stride=2, padding=0, ptype='max'):
        nc, w, h = img.shape

        pw_o, ph_o = int((w - size + 2 * padding) // stride) + 1, int((h - size + 2 * padding) // stride) + 1

        # pad the w and h of input image with 0 if padding>0
        conv_op_pad = np.pad(img, ((0,0), (padding,padding), (padding,padding)), mode='constant', constant_values=0)

        #initialize o/p matrix of above size with zeros
        op_mat = np.zeros((nc, pw_o, ph_o))

        for c in range(nc):
            for x in range(pw_o):
                for y in range(ph_o):
                    if ptype == 'max':
                        op_mat[c, x, y] = np.max(conv_op_pad[c, x*stride:x*stride+size, y*stride:y*stride+size]) # Calculate the maximum of elements in each of the specified regions and replace it in the associated index of initialized output matrix
                    elif ptype == 'avg':
                        op_mat[c, x, y] = np.mean(conv_op_pad[c, x*stride:x*stride+size, y*stride:y*stride+size])# Calculate the average of elements in each of the specified regions and replace it in the associated index of initialized output matrix

        return op_mat

    # TODO: Implement a conv-pool-relu-conv-pool-relu-conv-pool-relu network using the above two methods.
    # The input 'x' should have dimensionality num_channels x 400 x 400.
    def forward(self, x):
        num_channels, _, _ = x.shape

        filters1 = nr.randn(num_channels, 5, 5, 10)
        conv1 = self.conv(x, filters1)
        pool1 = self.pool(conv1, ptype='max')
        relu1 = np.maximum(pool1, 0)
        print(relu1.shape)

        filters2 = nr.randn(10, 5, 5, 10)
        conv2 = self.conv(relu1, filters2)
        pool2 = self.pool(conv2, ptype='max')
        relu2 = np.maximum(pool2, 0)
        print(relu2.shape)

        filters3 = nr.randn(10, 5, 5, 10)
        conv3 = self.conv(relu2, filters3)
        pool3 = self.pool(conv3, ptype='max')
        relu3 = np.maximum(pool3, 0)
        print(relu3.shape)

        return relu3

# Below is just a test code for your reference.
# This is one way to use the conv() and pool() methods above
def main(imfile='test.jpg'):
    bs = 1     # Minibatch size prior 16
    size = 400  # Input image size (w, h)
    filter_size = 5 # Choose your preferred size
    num_out_maps = 10 # Number of output feature maps.
    num_in_maps = 3

    img = cv2.imread(imfile) # Returns a numpy ndarray of shape (w, h, num_channel)
    img = cv2.resize(img, (size, size))
    img = np.transpose(img, (2, 0, 1)) # Permute the dimensions so the image shape is 3x400x400
    filters = nr.rand(num_in_maps, filter_size, filter_size, num_out_maps)
    #print("filter shape", filters.shape)
    #print("img shape", img.shape)
    net = MyCNN()
    #conv_out = net.conv(img, filters)
    # TODO: Make 'net.forward(img)' work 
    F_output = net.forward(img)
    #print(F_output.shape, F_output.size, F_output)
    
    for i in range(0, F_output.shape[0]):
        F_output[i] = cv2.resize(F_output[i], (F_output.shape[1], F_output.shape[2]))

        # Normalize the output values to the range 0-255
        
        if np.min(F_output[i]) != np.max(F_output[i]):
            F_output[i] = (F_output[i] - np.min(F_output[i])) * (255 / (np.max(F_output[i]) - np.min(F_output[i])))
        else:
            # Handle the case when min_val and max_val are equal
            F_output[i] = np.zeros_like(F_output[i])

        cv2.imwrite(f'OFeatures_{i}.jpg', F_output[i])
    print("done!")


if __name__ == '__main__':
    main()
